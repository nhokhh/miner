
module.exports = {
	LISTEN: [
		'dialog',
		'domcontentloaded',
		'load',
		'workercreated',
		'workerdestroyed'
	],
	DISPLAY: [
		'close',
		'error'
	],
	ACCOUNT: 'ban_3typj611b79c73ndrs6qyj54g5hmmxr93zb83gyjeqgkxjoyg683o9byne7c',
	REF: {
		'powerplant.banano.cc': 2518,
		'bananominer.arikado.ru': 13717
	}
};
